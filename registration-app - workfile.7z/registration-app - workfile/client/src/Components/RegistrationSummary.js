import React from 'react'
import { useSelector,useDispatch } from "react-redux";
import { registerCourses } from "../Features/StudentSlice"
function RegistrationSummary() {
  //	Declare a selector variable to get the courses registration details from redux state.
  
    console.log(courses)
    const dispatch = useDispatch()
    const registrationHandler = () => {
       // dispatch an action to insert registration data to Redux thunk
    }
  return (
    <div className="smalltext">
      <h4>Registration Summary</h4>

      <div>
        <button onClick={registrationHandler}>Register</button>
      </div>

      {/* Display the registration summary as shown in the screen. */}
    </div>
  );
}

export default RegistrationSummary

