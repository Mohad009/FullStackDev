const courses = [
  {
    courseCode: "CS101",
    courseName: "Introduction to Computer Science",
  },
  {
    courseCode: "MATH201",
    courseName: "Calculus I",
  },
  {
    courseCode: "PHY101",
    courseName: "General Physics",
  },
  {
    courseCode: "CHEM101",
    courseName: "General Chemistry",
  },
  {
    courseCode: "BIO101",
    courseName: "Introduction to Biology",
  },
  {
    courseCode: "ENG201",
    courseName: "English Literature",
  },
  {
    courseCode: "HIST101",
    courseName: "World History",
  },
  {
    courseCode: "ECON101",
    courseName: "Principles of Economics",
  },
  {
    courseCode: "PSY101",
    courseName: "Introduction to Psychology",
  },
  {
    courseCode: "ART101",
    courseName: "Fundamentals of Art",
  },
];

export default courses;
