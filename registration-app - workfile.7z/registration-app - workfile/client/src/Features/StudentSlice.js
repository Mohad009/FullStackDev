import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

//define the registerCourses thunk to send the
//  data received through the action from RegistrationSummary
// component to insert into the CourseRegInfos collection.
export const registerCourses = createAsyncThunk();

const initialState = {
  //initial values in redux store.
};
export const studentSlice = createSlice({
  name: "students",
  initialState,
  reducers: {
    addCourses(state, action) {
      //add the selected courses along with student id, semester and academic year to state.
    },
  },
  extraReducers: (builder) => {
    builder
     //addcases
  },
});
export default studentSlice.reducer;
export const { addCourses } = studentSlice.actions;
