import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import CourseRegModel from "./Models/CourseRegModel.js";
import * as dotenv from "dotenv"

const app = express();
app.use(express.json());
app.use(cors());
dotenv.config();


const URI = `mongodb+srv://${process.env.MONGO_USERNAME}:${process.env.MONGO_PASSWORD}@postitcluster.qld0q.mongodb.net/${process.env.MONGO_DATABASE}?retryWrites=true&w=majority&appName=PostITCluster`
mongoose.connect(URI);
app.listen(process.env.PORT, () => {
   console.log("You are connected");
});

//Express API method to receive the course registration data from the client and insert it into the CourseRegInfos collection.



