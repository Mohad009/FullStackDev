export const UsersData = [
  {
    name: "Jasmin Tumulak",
    email: "jasmine@utas.edu.om",
    password: "12345",
  },
  {
    name: "Marian Malig-on",
    email: "marian@utas.edu.om",
    password: "12345",
  },
  {
    name: "Ahmed Ali Jaboob",
    email: "ahmed@utas.edu.om",
    password: "12345",
  },
];
