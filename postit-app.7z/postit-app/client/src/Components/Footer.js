const Footer = () => {
  return (
    <footer className="footer">
      <div>--Write your name--|©2024|PostIT|All Rights Reserved.</div>
    </footer>
  );
};

export default Footer;
